<?php
require 'functions.php';

session_start();

if(! isset($_SESSION["username"]) ){
    header("Location: index.php");
    exit;
}
// ambil data di url
    $id = $_GET["id"];
    $result = mysqli_query($conn, "SELECT * FROM artikel WHERE id=$id");
    $data = mysqli_fetch_assoc($result);


// Cek apakah tombol submit sudah dipencet atau belum
if (isset($_POST["submit"])) {

    if (ubah($_POST) > 0) {

        echo " 
        <script>
            alert('Data Berhasil diubah');
            document.location.href='index-user.php';
        </script> ";
    } else {
        echo " 
        <script>
            alert('Data Tidak Berhasil diubah');
            document.location.href='ubah.php';
        </script> ";
        echo mysqli_error($conn);
    }
}


    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="asset/css/nav.css">
    <link rel="stylesheet" href="asset/css/login.css">
    <link rel="stylesheet" href="asset/css/logarea2.css">
    <link rel="stylesheet" href="asset/css/footer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo/logo2.png">
    <title>Junartikel</title>
    <script src="asset/JS/all.js"></script>
    
  

</head> 
<body>
    
   
    <div class="nav">
        <div class="nama-brand">
            <h1><a href="">Junartikel</a></h1>
        </div>
        <div class="logo-brand">
            <img src="gambar/logo/logo2.png" width="60px" alt="">
        </div>
        <div class="but-sign-in">
          
        </div>
    </div>
    <div class="body">
   
        <!-- <div class="logo-body">
            <img src="gambar/logo/logofj.png" width="300px" alt="">
        </div> -->
        
            <div class="logarea arealog" id="pop-up-form">
                <button class="logclose" onclick="change_class2('pop-up-form','logarea arealog')" >
                    &times
                </button>
                    <h1 class="logjudul">
                        Junartikel <i class="fas fa-user"></i>
                    </h1>
                  

                <form action="" method="POST">
                        <center>
                            <table class="form" >
                                <input type="hidden" name="id" value="<?= $data["id"];?>">
                                <tr>
                                    <td>
                                    <textarea class="box-area" name="caption" id="caption" cols="30" rows="10" ><?= $data["caption"];?></textarea>
                                    </td>
                                </tr>
                                  
                                <tr>
                                    <td>
                                    <button class="submit-button" type="submit" name="submit">Simpan</button>
                                    </td>
                                </tr>

                            </table>
                            
                        </center>

                    </form>
            </div>
        
        

    </div>
    <div  class="footer">
        
        <div class="contack">
            <h1>Contact</h1>
     
            <ul>
                <li><div class="wa"><i class="fab fa-whatsapp"></i> +62 852-2426-9056</div></li>
                <li><a href="https://www.instagram.com/fadiljuna/" target="ig"><div class="ig"><i class="fab fa-instagram"></i></div>  @fadiljuna </a></li>
                <li><a href="https://web.facebook.com/fadil.juna.77/" target="fb"><div class="fb"><i class="fab fa-facebook-f"> </i></div> Fadil Juna</a></li>
            </ul>
        </div>
        <div class="copyright">
            <h5><i class="far fa-copyright"></i> 2022-Junartikel</h5>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/7bd30e020c.js" crossorigin="anonymous"></script> 
    <!-- script yg di pakai untuk mengambil icon di font awesome -->
   
</body>
</html>
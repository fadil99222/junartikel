<?php

    require 'functions.php';
    session_start();
    if (isset($_POST["login"])) {

    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

    // cek username
    if (mysqli_num_rows($result) === 1) {
        $_SESSION['username']=$username;
        // cek password
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row["password"])) {
            header("Location:index-user.php");
            exit;
        }
    }
    $error = true;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="asset/css/nav.css">
    <link rel="stylesheet" href="asset/css/login.css">
    <link rel="stylesheet" href="asset/css/logarea.css">
    <link rel="stylesheet" href="asset/css/footer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="gambar/logo/logo2.png">
    <title>Junartikel</title>
    <script src="asset/JS/all.js"></script>
    
  

</head>
<body>
    
   
    <div class="nav">
        <div class="nama-brand">
            <h1><a href="">Junartikel</a></h1>
        </div>
        <div class="logo-brand">
            <img src="gambar/logo/logo2.png" width="60px" alt="">
        </div>
        <div class="but-sign-in">
            <a href="index-guest.php"><button class="guest-account">Akun Tamu</button></a>
            
            <button class="but-login" onclick="changeclass('pop-up-form','logarea arealog','logarea arealog2')" >Login</button>
        </div>
    </div>
    <div class="body">
        <div class="kata">
            <h1>Selamat Datang Di Junartikel</h1>
            <p>Artikel ini memuat content tentang ngoding, tugas, dan kehidupan sehari hari saya <br><br>Klik Akun Tamu untuk lanjut ke Artikel </p>
        </div>
        <!-- <div class="logo-body">
            <img src="gambar/logo/logofj.png" width="300px" alt="">
        </div> -->
        <div class="loginarea">
            <div class="logarea arealog" id="pop-up-form">
                <button class="logclose" onclick="change_class2('pop-up-form','logarea arealog')" >
                    &times
                </button>
                    <h1 class="logjudul">
                        Junartikel <i class="fas fa-user"></i>
                    </h1>
                    <?php if (isset($error)) : ?>
                        <div class="wrongpass"><i class="fas fa-times-circle"></i> <p>Username/password Salah. coba lagi</p></div>
                        <script>change_class2('pop-up-form','logarea arealog2');</script>
                    <?php endif; ?>

                <form action="" method="POST">
                    <label class="show-pass" >
                                <input type="checkbox" onclick="myFunction('password')">  <i class="far fa-eye"></i>
                    </label>

                    <table class="form" >

                        <tr>
                            <td>
                                <input class="input-text" type="text" name="username" placeholder="username" id="username" required>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <input class="input-text" type="password" name="password" placeholder="password" id="password" required>
                            </td>
                        </tr>
            
                        <tr>
                            <td>
                            <button class="submit-button" type="submit" name="login">Login <i class="fas fa-sign-in-alt"></i> </button>
                            </td>
                        </tr>
                    
                        
                    </table>

                    </form>
            </div>
        </div>
        

    </div>
    <div  class="footer">
        
        <div class="contack">
            <h1>Contact</h1>
     
            <ul>
                <li><div class="wa"><i class="fab fa-whatsapp"></i> +62 852-2426-9056</div></li>
                <li><a href="https://www.instagram.com/fadiljuna/" target="ig"><div class="ig"><i class="fab fa-instagram"></i></div>  @fadiljuna </a></li>
                <li><a href="https://web.facebook.com/fadil.juna.77/" target="fb"><div class="fb"><i class="fab fa-facebook-f"> </i></div> Fadil Juna</a></li>
            </ul>
        </div>
        <div class="copyright">
            <h5><i class="far fa-copyright"></i> 2022-Junartikel</h5>
        </div>
    </div>
    <script src="https://kit.fontawesome.com/7bd30e020c.js" crossorigin="anonymous"></script> 
    <!-- script yg di pakai untuk mengambil icon di font awesome -->
   
</body>
</html>
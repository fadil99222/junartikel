// berikut dua function yg di pakai untuk menampilkan halaman pop-up login
// kedua fanction di bawah ini memiliki cara kerja yg sama
// yaitu jika functionnya di panggil maka akan mengubah style elemen dengan id pop-up-form
function openForm() {
    document.getElementById("pop-up-form").style.display = "block";
}

function closeForm() {
    document.getElementById("pop-up-form").style.display = "none";
}

// function di bawah adalah function yg di pakai untuk melihat password cara kerja 
// dengan mendefinisikan sebuah variabel yg mengambil document di elemen ber id password
// kemudian di seleksi apakan tipe variabel ini sama dengan tipe password
// kalau iya maka ubah type nya jadi text
// kalau tidak  tipe nya tetap password
// referensi dari https://www.ketutrare.com/2018/08/menampilkan-password-di-textfield.html
function myFunction(el) {
    var x = document.getElementById(el);
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}


// function change class di pakai untuk mengganti kelas dari sebuah elemen
// funtion ini mempunyai 3 parameter yaitu elid atau elemen id 
// kemudian class_name nama kelas dari elemen tersebut kemudian target_class
// kemudian target_class nama pengganti class sebelumnya
// cara kerja mendefinisikan var x yg mengambil elemen dari id
// kemudian di seleksi apakah nama kelas dari x ini = class_name apabila sama
//maka nama kelas dari x akan di ganti menjadi target_class
//apabila tdk sama maka nama kelasnya menjadi class_name
function changeclass(elid,class_name,target_class){
    var x = document.getElementById(elid);
    if(x.className==class_name){
        x.className=target_class;
    }
    else{
        x.className=class_name;
    }
}

function change_class2(elid, target_class){
    var x= document.getElementById(elid)
    x.className=target_class;
}
function change_class3(el,class_name,target_class,el2){
    if(el.className==class_name){
        el.className=target_class;
    }
    else{
        el.className=class_name;
    }
}


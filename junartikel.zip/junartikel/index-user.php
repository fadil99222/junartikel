<?php
require 'functions.php';
session_start();

if(! isset($_SESSION["username"]) ){
    header("Location: index.php");
    exit;
}

$caption = query("SELECT * FROM artikel");
// mengecek tombol submit ketikan ingin menambahkan artikel baru 

if (isset($_POST["submit"])) {
    

    if (tambah($_POST) > 0) {

        echo " 
        <script>
            
            document.location.href='index-user.php';
        </script> ";
    } else {
        echo " 
        <script>
            
            document.location.href='index-user.php';
        </script> ";
        echo mysqli_error($conn);
    }
}

// mengecek tombol register yg di pakai untuk menambahkan user baru
// apabila sudah di tekan maka akan ada muncul notifikasi berhasil
if (isset($_POST["register"])) {
    if (registrasi($_POST) > 0) {
        echo " 
        <script>
            alert('Data Berhasil ditambahkan');
            
        </script> ";
    } else {
        echo mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="asset/css/nav2.css">
    <link rel="stylesheet" href="asset/css/upload.css">
    <link rel="stylesheet" href="asset/css/index.css">
    <link rel="stylesheet" href="asset/css/scroolbar.css">
    <link rel="stylesheet" href="asset/css/set_artikel.css">
    
    <link rel="stylesheet" href="asset/css/footer.css">
    <link rel="stylesheet" href="asset/css/registrasi.css">

    <link rel="icon" href="gambar/logo/logo2.png">

    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
1

    <script src="https://kit.fontawesome.com/7bd30e020c.js" crossorigin="anonymous"></script>
    <script src="asset/JS/all.js"></script>
    <!-- navbar -->
    <nav class="nav">
        
               <div class="nama-brand">
                   <h1><a href="">Junartikel</a></h1>
               </div>
               <div class="logo-brand">
                   <img src="gambar/logo/logo2.png" width="60px" alt="">
               </div>
               <div class="but-user">
                   <p>Admin</p>
                   
                   <button class="moreuser" onclick="changeclass('pop-up-form','logarea arealog','logarea arealog2')" >Tambah User <i class="fas fa-user-plus"></i></button>
                </div>

    </nav>

        <div class="body">
            <center>

                <div class="continer">
                    <!-- input untuk artikel baru -->
                    <div class="area-artikel">
                        <form action="" method="post">
                            <div class="upload">
                                <div class="upper-upload">
                                    <div class="foto-upload">
                                        <img src="gambar/logo/logo2.png" alt="">
                                    </div>
                                    <div class="upload-cap">
                                    <i class="fa-solid fa-gear"></i>
                                        <textarea class="upload-cap-text" name="caption" id="caption" cols="30" rows="10" placeholder="Apa yang anda pikirkan hari ini?" required ></textarea>
                                        <button class="submit-but" type="submit" name="submit">Kirim <i class="fas fa-sign-in-alt"></i> </button>
                                    </div>
                                </div>

                             </div>

                        </form>
                        <!-- memulai looping untuk menampilkan artikel -->
                        <?php $i = 1; ?>
                            <?php foreach ($caption as $cap) : ?>
                                <div class="artikel">
                                    <div class="head-artikel">
                                        <div class="left-side">
                                            <div class="foto-upload">
                                                <img src="gambar/logo/logo2.png" alt="">
                                            </div>
                                            <div class="nama-brand">
                                                <h2>Junartikel</h2>
                                            </div>

                                        </div>
                                        <!-- tombol untuk mengatur artikel -->
                                        <div class="set">
                                            <div id="sett" onclick="change_class3(this,'but-set','but-set2'); changeclass('but-setting','butset','butset2') " class="but-set">
                                                <div  class="butset">
                                                    <div class="icon-set">
                                                        <i class="fas fa-cog"></i> 
                                                    </div>
                                                    <!-- tombol untuk menghapus atau mengubah -->
                                                    <a href="hapus.php?id=<?= $cap["id"]; ?>">  <button class="Hapus"><i class="fas fa-trash"></i><p>Hapus</p></button></a>
                                                    <a href="ubah.php?id=<?= $cap["id"]; ?>">  <button class="Ubah"><i class="fas fa-edit"></i><p>Ubah</p></button></a>
                                                     

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="body-artikel">
                                        <!-- output artikel yg ada di database -->
                                        <p><?= $cap["caption"]; ?></p>
                                    </div>
                                </div>

                            <?php $i++; ?>
                         <?php endforeach; ?>
                  


                        
                    </div>
                    <!-- info tentang saya -->
                    <div class="info">
                        <div onclick="change_class3(this,'info-me','info-me2')" class="info-me">
                            <p>BIODATA</p>
                            <table>
                                <tr>
                                    <td>Nama</td>
                                    <td>:</td>
                                    <td>Ahmad Fadil junaldi</td>
                                </tr>
                                <tr>
                                    <td>NIM</td>
                                    <td>:</td>
                                    <td>60200120039</td>
                                </tr>
                                <tr>
                                    <td>Pekerjaan</td>
                                    <td>:</td>
                                    <td>Mahasiswa</td>
                                </tr>
                            </table>
                        </div>
                        <!-- contack -->
                        <div onclick="change_class3(this,'info-me','info-me2')" class="info-me">
                            <p>Contack us</p>
                            <table>
                                <tr>
                                    <td><div class="wa"><i class="fab fa-whatsapp"></i></div></td>
                                    <td>:</td>
                                    <td> +62 852-2426-9056</td>
                                </tr>
                                <tr>
                                    <td><div class="ig"><i class="fab fa-instagram"></i></div></td>
                                    <td> : </td>
                                    <td><a href="https://www.instagram.com/fadiljuna/" target="ig"> @fadiljuna </a></td>
                                </tr>
                                <tr>
                                    <td><div class="fb"><i class="fab fa-facebook-f"> </i></div></td>
                                    <td> : </td>
                                    <td><a href="https://web.facebook.com/fadil.juna.77/" target="fb"> Fadil Juna</a></td>
                                </tr>
                            </table>
                        </div>

                        <!-- halaman pop up untuk menambah user -->
                        <div class="loginarea">
                                <div class="logarea arealog" id="pop-up-form">
                                    <button class="logclose" onclick="change_class2('pop-up-form','logarea arealog')" >
                                        &times
                                    </button>
                                
                                        <h1 class="logjudul">
                                            Registrasi <i class="fas fa-user"></i>
                                        </h1>
                                        

                                    <form action="" method="POST">
                                        <label class="show-pass" >
                                                    <input type="checkbox" onclick="myFunction('password')">  <i class="far fa-eye"></i>
                                        </label>
                                        <label class="show-pass2" >
                                                    <input type="checkbox" onclick="myFunction('password2')">  <i class="far fa-eye"></i>
                                        </label>

                                        <table class="form" >

                                            <tr>
                                                <td>
                                                    <input class="input-text" type="text" name="username" placeholder="username" id="username" required>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                <input class="input-text" type="password" name="password" placeholder="password" id="password" required>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                <input class="input-text" type="password" name="password2" placeholder="Konfirmasi Passwoed" id="password2" required>
                                                </td>
                                            </tr>
                                
                                            <tr>
                                                <td>
                                                <button class="submit-button" type="submit" name="register">Login <i class="fas fa-sign-in-alt"></i> </button>
                                                </td>
                                            </tr>
                                        
                                            
                                        </table>

                                    </form>
                            </div>
                    </div>
                </div>
            </center>
        </div>


    
</body>
</html>
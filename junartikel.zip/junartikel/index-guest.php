<?php
require 'functions.php';
session_start();
if (isset($_POST["login"])) {
    
    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

    // cek username
    if (mysqli_num_rows($result) === 1) {
        $_SESSION['username']=$username;
        // cek password
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row["password"])) {
            header("Location:index-user.php");
            exit;
        }
    }
    $error = true;
    }
$caption = query("SELECT * FROM artikel");
// Cek apakah tombol submit sudah dipencet atau belum

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="asset/css/nav2.css">
    <link rel="stylesheet" href="asset/css/upload.css">
    <link rel="stylesheet" href="asset/css/index.css">
    <link rel="stylesheet" href="asset/css/scroolbar.css">
    <link rel="stylesheet" href="asset/css/set_artikel.css">
    
    <link rel="stylesheet" href="asset/css/footer.css">
    <link rel="stylesheet" href="asset/css/registrasi.css">

    <link rel="icon" href="gambar/logo/logo2.png">

    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
1

    <script src="https://kit.fontawesome.com/7bd30e020c.js" crossorigin="anonymous"></script>
    <script src="asset/JS/all.js"></script>     
    <nav class="nav">
        
               <div class="nama-brand">
                   <h1><a href="">Junartikel</a></h1>
               </div>
               <div class="logo-brand">
                   <img src="gambar/logo/logo2.png" width="60px" alt="">
               </div>
               <div class="but-user">
                   <p>Guest-account</p>
                   <!-- <button class="guest-account"><a href="">Akun Tamu</a></button> -->
                   <button class="moreuser" onclick="changeclass('pop-up-form','arealog','arealog2')" >Login <i class="fas fa-sign-in-alt"></i></button>
                </div>

    </nav>

        <div class="body">
            <center>

                <div class="continer">
                    <div class="area-artikel">
                        
                        <?php $i = 1; ?>
                            <?php foreach ($caption as $cap) : ?>
                                <div class="artikel">
                                    <div class="head-artikel">
                                        <div class="left-side">
                                            <div class="foto-upload">
                                                <img src="gambar/logo/logo2.png" alt="">
                                            </div>
                                            <div class="nama-brand">
                                                <h2>Junartikel</h2>
                                            </div>

                                        </div>
                                      
                                    </div>
                                    <div class="body-artikel">
                                        <p><?= $cap["caption"]; ?></p>
                                    </div>
                                </div>

                            <?php $i++; ?>
                         <?php endforeach; ?>
                  


                        
                    </div>
                    <div class="info">
                        <div onclick="change_class3(this,'info-me','info-me2')" class="info-me">
                            <p>BIODATA</p>
                            <table>
                                <tr>
                                    <td>Nama</td>
                                    <td>:</td>
                                    <td>Ahmad Fadil junaldi</td>
                                </tr>
                                <tr>
                                    <td>NIM</td>
                                    <td>:</td>
                                    <td>60200120039</td>
                                </tr>
                                <tr>
                                    <td>Pekerjaan</td>
                                    <td>:</td>
                                    <td>Mahasiswa</td>
                                </tr>
                            </table>
                        </div>
                        <div onclick="change_class3(this,'info-me','info-me2')" class="info-me">
                            <p>Contack us</p>
                            <table>
                                <tr>
                                    <td><div class="wa"><i class="fab fa-whatsapp"></i></div></td>
                                    <td>:</td>
                                    <td> +62 852-2426-9056</td>
                                </tr>
                                <tr>
                                    <td><div class="ig"><i class="fab fa-instagram"></i></div></td>
                                    <td> : </td>
                                    <td><a href="https://www.instagram.com/fadiljuna/" target="ig"> @fadiljuna </a></td>
                                </tr>
                                <tr>
                                    <td><div class="fb"><i class="fab fa-facebook-f"> </i></div></td>
                                    <td> : </td>
                                    <td><a href="https://web.facebook.com/fadil.juna.77/" target="fb"> Fadil Juna</a></td>
                                </tr>
                            </table>
                        </div>
                        <div class="loginarea">
                                <div class="logarea arealog" id="pop-up-form">
                                    <button class="logclose" onclick="change_class2('pop-up-form','arealog')" >
                                        &times
                                    </button>
                                
                                        <h1 class="logjudul">
                                            Login <i class="fas fa-user"></i>
                                        </h1>
                                        

                                    <form action="" method="POST">
                                        <label class="show-pass" >
                                                    <input type="checkbox" onclick="myFunction('password')">  <i class="far fa-eye"></i>
                                        </label>
     

                                        <table class="form" >

                                            <tr>
                                                <td>
                                                    <input class="input-text" type="text" name="username" placeholder="username" id="username" required>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                <input class="input-text" type="password" name="password" placeholder="password" id="password" required>
                                                </td>
                                            </tr>
                                          
                                
                                            <tr>
                                                <td>
                                                <button class="submit-button" type="submit" name="login">Login <i class="fas fa-sign-in-alt"></i> </button>
                                                </td>
                                            </tr>
                                        
                                            
                                        </table>

                                    </form>
                            </div>
                    </div>
                </div>
            </center>
        </div>


    
</body>
</html>
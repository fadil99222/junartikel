<?php 

require 'functions.php';
$id = $_GET["id"];
session_start();

if(! isset($_SESSION["username"]) ){
    header("Location: index.php");
    exit;
}


if(hapus($id) > 0){
    echo " 
        <script>
            alert('Data Berhasil dihapus');
            document.location.href='index-user.php';
        </script> ";
}else{
    echo " 
        <script>
            alert('Data tidak berhasil dihapus');
            document.location.href='index-user.php';
        </script> ";
} 
?>